import sys
from .jupyter_mindmaps import cli
def run():
    cli()